// index.js
var express = require("express");
var app = express();
var flash = require('connect-flash');
var morgan = require('morgan');

var zlib = require('zlib');
var fs = require('fs');

var gzip = zlib.createGzip();
var r = fs.createReadStream('./index.js');
var w = fs.createWriteStream('./index.js.gz');
r.pipe(gzip).pipe(w);

var port=Number(process.env.PORT || 3000);

app.use(flash());

//connect to db
require('./db/connect.js');

//router
require('./router/router.js')(app, express);

app.listen(port, function() {
    console.log("Hey! My API is running...");
});

module.exports = app;